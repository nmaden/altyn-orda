<?php

return [
    'name' => 'Entity'
];
