<?php
namespace Modules\Entity\Model\Categories;

use Modules\Entity\ModelParent;

class Categories extends ModelParent {
    protected $table = 'categories';
    
}
