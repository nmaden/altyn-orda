<?php 
namespace Modules\Entity\Model\Gallery\Application;

use Modules\Entity\Model\University\University;



trait Presenter {
	
   
	

	

}

