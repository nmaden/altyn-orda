<?php

return [
    'name' => 'Admin'
];
