<div class="col-md-12" >

<input-text name="name" :model='$model' />

<br>
<input-text name="note" :model='$model' />





</div>