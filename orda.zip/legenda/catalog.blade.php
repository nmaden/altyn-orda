


    <div class="about__desc page__description">
        <div class="container">

            <div class="bread-line">
                <ul class="bread-crambs">
                    <li class="breadcrumb-item">
                      <a href="/">						
						@lang('front_main.bread.home')
                      </a>
                    </li>
                    <li>
                        <span>
						    История в легендах
                       </span>
                    </li>
                </ul>
            </div>

            <div class="section__title--block">
                <h1 class="section__title">
                    История в легендах
                </h1>
            </div>

            <div class="page__description--text">

                <div class="sights__block calendar__block legenda__block">
                    <div class="row">

                        <div class="col-lg-4 col-md-6">
                            <div class="sights__item legenda__item">
                                <div class="sights__item--img">
                                    <a href="/about/legenda-item">
                                        <img src="/img/karagandy-alash_10.jpg" alt="">
									</a>
                                </div>
                                <div class="sights__item--info">
                                    <div class="sights__item--title">
									    <a href="/about/legenda-item">
                                            Сказание об «Аксак-кулан» («Хромой кулан»)
                                        </a>
									</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="sights__item legenda__item">
                                <div class="sights__item--img">
                                    <a href="#">
                                        <img src="/img/karagandy-alash_1.jpg" alt="">
									</a>
                                </div>
                                <div class="sights__item--info">
                                    <div class="sights__item--title">
									    <a href="#">
                                            «Гора Манырак - Блеяние овцы»
                                        </a>
									</div>
                                </div>
                            </div>
                        </div>

                        <!--
                        <div class="col-lg-4 col-md-6">
                            <div class="sights__item legenda__item">
                                <div class="sights__item--img">
                                    <a href="/about/legenda-item">
                                        <img src="/img/karagandy-alash_1.jpg" alt="">
									</a>
                                </div>
                                <div class="sights__item--info">
                                    <div class="sights__item--title">
									    <a href="/about/legenda-item">
                                            «Гора Манырак - Блеяние овцы»
                                        </a>
									</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="sights__item legenda__item">
                                <div class="sights__item--img">
                                    <a href="/about/legenda-item">
                                        <img src="/img/karagandy-alash_1.jpg" alt="">
									</a>
                                </div>
                                <div class="sights__item--info">
                                    <div class="sights__item--title">
									    <a href="/about/legenda-item">
                                            «Гора Манырак - Блеяние овцы»
                                        </a>
									</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="sights__item legenda__item">
                                <div class="sights__item--img">
                                    <a href="/about/legenda-item">
                                        <img src="/img/karagandy-alash_1.jpg" alt="">
									</a>
                                </div>
                                <div class="sights__item--info">
                                    <div class="sights__item--title">
									    <a href="/about/legenda-item">
                                            «Гора Манырак - Блеяние овцы»
                                        </a>
									</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="sights__item legenda__item">
                                <div class="sights__item--img">
                                    <a href="/about/legenda-item">
                                        <img src="/img/karagandy-alash_1.jpg" alt="">
									</a>
                                </div>
                                <div class="sights__item--info">
                                    <div class="sights__item--title">
									    <a href="/about/legenda-item">
                                            «Гора Манырак - Блеяние овцы»
                                        </a>
									</div>
                                </div>
                            </div>
                        </div>
                        -->
                        
                    </div>

                </div>





            </div>

        </div>
    </div>

